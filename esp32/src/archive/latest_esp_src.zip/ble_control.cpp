#include "ble_control.h"

#include <Arduino.h>
#include <NimBLEDevice.h>
#include <driver/i2s.h>

#include "config.h"
#include "mic.h"
#include "lib_websocket.h"
#include "MiP_commands.h"
#include "audio_tx_queue.h"

// These live in main.cpp.
extern MiP MyMiP;

// -----------------------------------------------------------------------------
// Global mode state
// -----------------------------------------------------------------------------
ControlMode currentMode = MODE_MANUAL;

static NimBLECharacteristic* g_statusChar = nullptr;
static bool g_bleStarted = false;
static bool g_bleRecording = false;
static bool g_pendingPttStart = false;
static bool g_pendingPttStop = false;
static bool g_pttStopping = false;
static unsigned long g_pttStartedAtMs = 0;
static unsigned long g_pttStopRequestedAtMs = 0;
static const unsigned long MIN_PTT_MS = 900;
static const unsigned long PTT_FLUSH_MS = 220;
static unsigned long g_pttStartMs = 0;
static unsigned long g_lastPttStopMs = 0;

// Keep recordings long enough for the Realtime API commit threshold.
// 24 kHz, 16-bit mono = 48,000 bytes/sec, so 100 ms = 4,800 bytes.
// 650 ms gives the mic task and WebSocket a safer cushion.
static const unsigned long MIN_PTT_RECORD_MS = 650;
static const unsigned long PTT_STOP_FLUSH_MS = 120;
static const unsigned long PTT_RESTART_GUARD_MS = 250;

// Conservative MiP command defaults.
// The WowWee protocol documents drive-forward speed 0-30 and turn speed 0-24.
// We keep defaults lower while testing the robot from a phone/web app.
static const int DEFAULT_DRIVE_SPEED = 12;
static const int DEFAULT_DRIVE_TIME  = 15;
static const int DEFAULT_TURN_SPEED  = 12;
static const int DEFAULT_TURN_ANGLE  = 45;

const char* controlModeToString(ControlMode mode)
{
  switch (mode)
  {
    case MODE_MANUAL:         return "manual";
    case MODE_GPT_ASSISTED:   return "gpt_assisted";
    case MODE_GPT_AUTONOMOUS: return "gpt_autonomous";
    default:                  return "unknown";
  }
}

ControlMode controlModeFromString(const String& modeName)
{
  String m = modeName;
  m.trim();
  m.toUpperCase();

  if (m == "MANUAL" || m == "MODE:MANUAL") return MODE_MANUAL;
  if (m == "GPT_ASSISTED" || m == "ASSISTED" || m == "MODE:GPT_ASSISTED") return MODE_GPT_ASSISTED;
  if (m == "GPT_AUTONOMOUS" || m == "AUTONOMOUS" || m == "MODE:GPT_AUTONOMOUS") return MODE_GPT_AUTONOMOUS;

  return currentMode;
}

bool isManualMode()        { return currentMode == MODE_MANUAL; }
bool isGptAssistedMode()   { return currentMode == MODE_GPT_ASSISTED; }
bool isGptAutonomousMode() { return currentMode == MODE_GPT_AUTONOMOUS; }

bool allowsGptMotion()
{
  return currentMode == MODE_GPT_ASSISTED || currentMode == MODE_GPT_AUTONOMOUS;
}

bool allowsManualMotion()
{
  return currentMode == MODE_MANUAL;
}

void applyModeLED()
{
  switch (currentMode)
  {
    case MODE_MANUAL:
      MyMiP.setChestLED(0, 40, 255);       // blue
      break;

    case MODE_GPT_ASSISTED:
      MyMiP.setChestLED(140, 0, 255);      // purple
      break;

    case MODE_GPT_AUTONOMOUS:
      MyMiP.setChestLED(0, 255, 80);       // green
      break;
  }
}

void setControlMode(ControlMode mode, bool stopRobot)
{
  if (currentMode == mode)
  {
    applyModeLED();
    publishBleStatus("mode");
    return;
  }

  if (stopRobot)
  {
    MyMiP.stop();
  }

  currentMode = mode;
  applyModeLED();

  Serial.print("[MODE] ");
  Serial.println(controlModeToString(currentMode));

  publishBleStatus("mode");
}

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------
static int valueAfterPrefix(const String& cmd, const char* prefix, int fallback)
{
  String p(prefix);
  if (!cmd.startsWith(p)) return fallback;
  return cmd.substring(p.length()).toInt();
}

static bool parseCsv3(const String& payload, int& a, int& b, int& c)
{
  int first = payload.indexOf(',');
  int second = payload.indexOf(',', first + 1);

  if (first < 0 || second < 0) return false;

  a = payload.substring(0, first).toInt();
  b = payload.substring(first + 1, second).toInt();
  c = payload.substring(second + 1).toInt();
  return true;
}

static void sendRobotStateToServer(const char* eventName)
{
  if (!client.available()) return;

  // Avoid injecting extra text frames into the server input stream while mic audio
  // is actively being recorded. Mode/status can be sent again after PTT stops.
  if (g_bleRecording) return;

  String json = "{";
  json += "\"type\":\"robot_state\",";
  json += "\"event\":\"";
  json += eventName;
  json += "\",";
  json += "\"mode\":\"";
  json += controlModeToString(currentMode);
  json += "\"";
  json += "}";

  sendMessage(json.c_str());
}

void publishBleStatus(const char* eventName)
{
  String json = "{";
  json += "\"event\":\"";
  json += eventName;
  json += "\",";
  json += "\"mode\":\"";
  json += controlModeToString(currentMode);
  json += "\",";
  json += "\"recording\":";
  json += g_bleRecording ? "true" : "false";
  json += ",\"ws\":";
  json += client.available() ? "true" : "false";
  json += "}";

  Serial.print("[BLE STATUS] ");
  Serial.println(json);

  if (g_statusChar)
  {
    g_statusChar->setValue(json.c_str());
    g_statusChar->notify();
  }

  sendRobotStateToServer(eventName);
}

void beginPttRecording(const char* source)
{
  if (isManualMode())
  {
    Serial.println("[PTT] Ignored in manual mode");
    publishBleStatus("ptt_ignored_manual_mode");
    return;
  }

  if (g_bleRecording || g_pendingPttStart || g_pttStopping)
  {
    Serial.println("[PTT] Start ignored; already recording/pending");
    publishBleStatus("ptt_start_ignored");
    return;
  }

  Serial.print("[PTT] START requested from ");
  Serial.println(source);

  g_pendingPttStart = true;
}

void endPttRecording(const char* source)
{
  if (!g_bleRecording && !g_pendingPttStart)
  {
    Serial.println("[PTT] Stop ignored; not recording");
    publishBleStatus("ptt_stop_ignored");
    return;
  }

  if (g_pendingPttStop || g_pttStopping)
  {
    Serial.println("[PTT] Stop ignored; stop already pending");
    return;
  }

  Serial.print("[PTT] STOP requested from ");
  Serial.println(source);

  g_pendingPttStop = true;
}

// Runs from loopBleControl(), not from the NimBLE callback.
// This keeps WebSocket sends and timing-sensitive audio work out of the BLE
// callback thread.
static void processPttState()
{
  if (g_pendingPttStart)
  {
    g_pendingPttStart = false;

    if (!client.available())
    {
      Serial.println("[PTT] Start ignored; websocket disconnected");
      publishBleStatus("ptt_start_no_ws");
      return;
    }

    clearAudioTxQueue();

    // Tell the server to open a new recording first.
    sendMessage("START_RECORD");
    delay(40);

    i2s_zero_dma_buffer(I2S_PORT_SPEAKER);
    i2s_zero_dma_buffer(I2S_PORT_MIC);
    i2s_start(I2S_PORT_MIC);

    g_pttStartedAtMs = millis();
    g_bleRecording = true;
    g_pttStopping = false;

    setRecording(true);

    Serial.println("[PTT] START active");
    publishBleStatus("ptt_start");
  }

  if (g_pendingPttStop && g_bleRecording)
  {
    unsigned long elapsed = millis() - g_pttStartedAtMs;

    if (elapsed < MIN_PTT_MS)
    {
      return; // wait until minimum duration is met
    }

    g_pendingPttStop = false;
    g_pttStopping = true;
    g_pttStopRequestedAtMs = millis();

    // Stop producing new mic chunks first.
    setRecording(false);
    g_bleRecording = false;

    Serial.println("[PTT] STOP flushing queued audio");
  }

  if (g_pttStopping)
  {
    // Continue draining queued audio chunks before sending STOP_RECORD.
    serviceAudioTxQueue(6);

    if ((millis() - g_pttStopRequestedAtMs) >= PTT_FLUSH_MS || audioTxQueueDepth() == 0)
    {
      sendMessage("STOP_RECORD");

      i2s_zero_dma_buffer(I2S_PORT_MIC);
      i2s_start(I2S_PORT_SPEAKER);

      g_pttStopping = false;

      Serial.println("[PTT] STOP sent after flush");
      publishBleStatus("ptt_stop");
    }
  }
}

// -----------------------------------------------------------------------------
// Command handler
// -----------------------------------------------------------------------------
void handleBleCommand(String cmd)
{
  cmd.trim();
  if (cmd.length() == 0) return;

  Serial.print("[BLE CMD RAW] ");
  Serial.println(cmd);

  String upper = cmd;
  upper.toUpperCase();

  if (upper == "STATUS")
  {
    publishBleStatus("status_request");
    return;
  }

  if (upper == "MODE:MANUAL")
  {
    setControlMode(MODE_MANUAL);
    return;
  }

  if (upper == "MODE:GPT_ASSISTED")
  {
    setControlMode(MODE_GPT_ASSISTED);
    return;
  }

  if (upper == "MODE:GPT_AUTONOMOUS")
  {
    setControlMode(MODE_GPT_AUTONOMOUS);
    return;
  }

  if (upper == "MODE:NEXT")
  {
    ControlMode next = MODE_MANUAL;
    if (currentMode == MODE_MANUAL) next = MODE_GPT_ASSISTED;
    else if (currentMode == MODE_GPT_ASSISTED) next = MODE_GPT_AUTONOMOUS;
    else next = MODE_MANUAL;

    setControlMode(next);
    return;
  }

  if (upper == "PTT:START")
  {
    beginPttRecording("ble");
    return;
  }

  if (upper == "PTT:STOP")
  {
    endPttRecording("ble");
    return;
  }

  // Stop is always allowed.
  if (upper == "MIP:STOP" || upper == "STOP" || upper == "ESTOP")
  {
    MyMiP.stop();
    MyMiP.setChestLED(255, 0, 0);
    delay(120);
    applyModeLED();
    publishBleStatus("stop");
    return;
  }

  // Pass 1: local motion commands are only active in manual mode.
  // This prevents an accidental phone button press from fighting GPT later.
  if (!allowsManualMotion())
  {
    Serial.println("[BLE] Manual MiP command ignored outside manual mode");
    publishBleStatus("manual_command_ignored");
    return;
  }

  if (upper == "MIP:FORWARD")
  {
    MyMiP.driveForward(DEFAULT_DRIVE_SPEED, DEFAULT_DRIVE_TIME);
    publishBleStatus("forward");
  }
  else if (upper == "MIP:BACKWARD")
  {
    MyMiP.distanceDrive(-10, 0);
    publishBleStatus("backward");
  }
  else if (upper == "MIP:LEFT")
  {
    MyMiP.turnAngle(0, DEFAULT_TURN_SPEED, DEFAULT_TURN_ANGLE);
    publishBleStatus("left");
  }
  else if (upper == "MIP:RIGHT")
  {
    MyMiP.turnAngle(1, DEFAULT_TURN_SPEED, DEFAULT_TURN_ANGLE);
    publishBleStatus("right");
  }
  else if (upper.startsWith("MIP:DRIVE:"))
  {
    String payload = cmd.substring(String("MIP:DRIVE:").length());
    int comma = payload.indexOf(',');
    if (comma > 0)
    {
      int distance = payload.substring(0, comma).toInt();
      int angle = payload.substring(comma + 1).toInt();
      distance = constrain(distance, -100, 100);
      angle = constrain(angle, -360, 360);
      MyMiP.distanceDrive(distance, angle);
      publishBleStatus("drive_distance");
    }
  }
  else if (upper == "MIP:STAND" || upper == "MIP:STAND_ANY")
  {
    MyMiP.standUp(2);
    publishBleStatus("stand");
  }
  else if (upper == "MIP:STAND_FRONT")
  {
    MyMiP.standUp(0);
    publishBleStatus("stand_front");
  }
  else if (upper == "MIP:STAND_BACK")
  {
    MyMiP.standUp(1);
    publishBleStatus("stand_back");
  }
  else if (upper.startsWith("MIP:SOUND:"))
  {
    int soundId = valueAfterPrefix(upper, "MIP:SOUND:", 1);
    soundId = constrain(soundId, 1, 106);
    MyMiP.playSpecific(soundId);
    publishBleStatus("sound");
  }
  else if (upper.startsWith("MIP:VOLUME:"))
  {
    int volume = valueAfterPrefix(upper, "MIP:VOLUME:", 4);
    volume = constrain(volume, 0, 7);
    MyMiP.setVolume(volume);
    publishBleStatus("volume");
  }
  else if (upper.startsWith("MIP:LED:"))
  {
    String payload = cmd.substring(String("MIP:LED:").length());
    int r, g, b;
    if (parseCsv3(payload, r, g, b))
    {
      MyMiP.setChestLED(
        constrain(r, 0, 255),
        constrain(g, 0, 255),
        constrain(b, 0, 255)
      );
      publishBleStatus("chest_led");
    }
  }
  else if (upper.startsWith("MIP:HEAD:"))
  {
    String payload = cmd.substring(String("MIP:HEAD:").length());
    int a = 1, b = 1, c = 1, d = 1;

    int c1 = payload.indexOf(',');
    int c2 = payload.indexOf(',', c1 + 1);
    int c3 = payload.indexOf(',', c2 + 1);
    if (c1 > 0 && c2 > 0 && c3 > 0)
    {
      a = payload.substring(0, c1).toInt();
      b = payload.substring(c1 + 1, c2).toInt();
      c = payload.substring(c2 + 1, c3).toInt();
      d = payload.substring(c3 + 1).toInt();

      MyMiP.setHeadLEDs(
        constrain(a, 0, 3),
        constrain(b, 0, 3),
        constrain(c, 0, 3),
        constrain(d, 0, 3)
      );
      publishBleStatus("head_leds");
    }
  }
  else
  {
    Serial.print("[BLE] Unknown command: ");
    Serial.println(cmd);
    publishBleStatus("unknown_command");
  }
}

// -----------------------------------------------------------------------------
// BLE service
// -----------------------------------------------------------------------------
class CommandCallbacks : public NimBLECharacteristicCallbacks
{
public:
  void onWrite(NimBLECharacteristic* characteristic, NimBLEConnInfo& connInfo) override
  {
    std::string value = characteristic->getValue();

    Serial.print("[BLE WRITE] length=");
    Serial.println(value.length());

    if (!value.empty())
    {
      String cmd = String(value.c_str());
      handleBleCommand(cmd);
    }
  }
};

void setupBleControl()
{
  if (g_bleStarted) return;

  Serial.println("[BLE] Starting MiP BLE control service");

  NimBLEDevice::init(MIP_BLE_DEVICE_NAME);
  NimBLEDevice::setDeviceName(MIP_BLE_DEVICE_NAME);
  NimBLEDevice::setPower(ESP_PWR_LVL_P9);

  NimBLEServer* server = NimBLEDevice::createServer();
  NimBLEService* service = server->createService(MIP_BLE_SERVICE_UUID);

  NimBLECharacteristic* commandChar = service->createCharacteristic(
    MIP_BLE_COMMAND_CHAR_UUID,
    NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR
  );

  commandChar->setCallbacks(new CommandCallbacks());

  g_statusChar = service->createCharacteristic(
    MIP_BLE_STATUS_CHAR_UUID,
    NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY
  );

  service->start();

  NimBLEAdvertising* advertising = NimBLEDevice::getAdvertising();

  // Keep the primary advertisement small so it does not exceed the legacy BLE
  // payload length. The human-readable name goes in scan response data.
  NimBLEAdvertisementData advData;
  advData.setFlags(0x06);
  advData.setCompleteServices(NimBLEUUID(MIP_BLE_SERVICE_UUID));
  advertising->setAdvertisementData(advData);

  NimBLEAdvertisementData scanData;
  scanData.setName(MIP_BLE_DEVICE_NAME);
  advertising->setScanResponseData(scanData);

  advertising->start();

  g_bleStarted = true;

  Serial.println("[BLE] Advertising as MiP-Bot");
  publishBleStatus("ble_started");
}

void loopBleControl()
{
  processPttState();
}
