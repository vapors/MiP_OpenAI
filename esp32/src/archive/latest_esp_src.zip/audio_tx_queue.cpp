#include "audio_tx_queue.h"

#include "config.h"
#include "lib_websocket.h"

struct AudioTxChunk
{
  uint16_t frames;
  int16_t samples[bufferLen];
};

static QueueHandle_t g_audioTxQueue = nullptr;
static const uint8_t AUDIO_TX_QUEUE_LEN = 24;

bool setupAudioTxQueue()
{
  if (g_audioTxQueue) return true;

  g_audioTxQueue = xQueueCreate(AUDIO_TX_QUEUE_LEN, sizeof(AudioTxChunk));
  if (!g_audioTxQueue)
  {
    Serial.println("[AUDIO TX] Failed to create audio TX queue");
    return false;
  }

  Serial.printf("[AUDIO TX] Queue ready: %u chunks x %u frames\n",
                AUDIO_TX_QUEUE_LEN, bufferLen);
  return true;
}

void clearAudioTxQueue()
{
  if (g_audioTxQueue)
  {
    xQueueReset(g_audioTxQueue);
  }
}

bool enqueueAudioChunk(const int16_t* samples, size_t frames)
{
  if (!g_audioTxQueue || !samples || frames == 0) return false;

  AudioTxChunk chunk;
  if (frames > bufferLen) frames = bufferLen;

  chunk.frames = (uint16_t)frames;
  memcpy(chunk.samples, samples, frames * sizeof(int16_t));

  if (xQueueSend(g_audioTxQueue, &chunk, 0) != pdTRUE)
  {
    // Drop oldest chunk, then try once more. This preserves recency and avoids
    // blocking the mic task if the network stalls.
    AudioTxChunk dropped;
    xQueueReceive(g_audioTxQueue, &dropped, 0);

    if (xQueueSend(g_audioTxQueue, &chunk, 0) != pdTRUE)
    {
      Serial.println("[AUDIO TX] Queue full; dropped mic chunk");
      return false;
    }
  }

  return true;
}

void serviceAudioTxQueue(uint8_t maxChunks)
{
  if (!g_audioTxQueue) return;

  AudioTxChunk chunk;
  uint8_t sent = 0;

  while (sent < maxChunks && xQueueReceive(g_audioTxQueue, &chunk, 0) == pdTRUE)
  {
    if (chunk.frames > 0)
    {
      sendBinaryData(chunk.samples, chunk.frames * sizeof(int16_t));
      sent++;
    }
  }
}

size_t audioTxQueueDepth()
{
  if (!g_audioTxQueue) return 0;
  return uxQueueMessagesWaiting(g_audioTxQueue);
}
